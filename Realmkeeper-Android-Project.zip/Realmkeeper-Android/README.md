# Realmkeeper Android app

This project builds a simple Android APK wrapper for the existing Realmkeeper multiplayer web app.

## What it does
- Installs as an Android app named **Realmkeeper**
- Opens the existing Realmkeeper website in a full-screen WebView
- Supports JavaScript and browser storage required by the web app and anonymous Supabase sign-in
- Uses Android's back button for in-app navigation

## Build the APK with GitHub Actions (free)
1. Create a new **public or private** GitHub repository named `realmkeeper-android`.
2. Upload the contents of this folder to the repository root (not the folder itself).
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Open **Build Realmkeeper APK** and press **Run workflow** (or wait for the first push build).
5. When the run finishes successfully, open it and download the `Realmkeeper-Android-APK` artifact.
6. Extract the ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from the browser or file manager you used.

## Important
This is a WebView-based Android app, not a native rewrite of all Realmkeeper screens. It uses the existing live website and backend. The APK is unsigned for Play Store distribution (Android can install a debug APK after confirmation).
